//
// Created by student on 29/02/24.
//

#ifndef UNTITLED_JOB_H
#define UNTITLED_JOB_H


class Job {

};


#endif //UNTITLED_JOB_H
