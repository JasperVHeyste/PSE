//
// Created by student on 29/02/24.
//

#ifndef UNTITLED_PRINTER_H
#define UNTITLED_PRINTER_H
#include <string>
using namespace std;

class Printer {
private:
    int emission;
    int speed; // pager per minute
    string type;
};


#endif //UNTITLED_PRINTER_H
