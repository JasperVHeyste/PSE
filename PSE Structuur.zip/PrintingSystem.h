//
// Created by student on 29/02/24.
//

#ifndef UNTITLED_PRINTINGSYSTEM_H
#define UNTITLED_PRINTINGSYSTEM_H
#include <vector>
#include "Printer.h"


class PrintingSystem {
private:
    vector<Printer> printers;


public:
    virtual ~PrintingSystem();

};


#endif //UNTITLED_PRINTINGSYSTEM_H
