//
// Created by student on 29/02/24.
//

#include "Node.h"

Node::Node(Job *item) : item(item) {}
